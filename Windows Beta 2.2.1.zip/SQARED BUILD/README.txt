SQUARED
a square game

This game is still in development. 

(possible) Future Additions
 - Level saving/loading
 - Better mobile support


If you have any suggestions, please leave them in the issues page!